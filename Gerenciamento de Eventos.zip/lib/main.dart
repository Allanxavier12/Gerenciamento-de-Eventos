import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:share_plus/share_plus.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gerenciador de Eventos',
      theme: ThemeData(
        primaryColor: Color.fromRGBO(2, 62, 131, 1),
        accentColor: Colors.amber,
        visualDensity: VisualDensity.adaptivePlatformDensity,
        textTheme: TextTheme(
          headline6: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),
          subtitle1: TextStyle(color: Colors.grey[600]),
        ),
      ),
      home: LoginScreen(),
    );
  }
}

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  void _login() {
    if (_formKey.currentState!.validate()) {
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => EventManager(),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Login'),
        backgroundColor: Color.fromRGBO(2, 62, 131, 1),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              TextFormField(
                controller: _usernameController,
                decoration: InputDecoration(
                  labelText: 'Username',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your username';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              TextFormField(
                controller: _passwordController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                obscureText: true,
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please enter your password';
                  }
                  return null;
                },
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _login,
                style: ElevatedButton.styleFrom(
                  primary: Color.fromRGBO(2, 62, 131, 1),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
                child: Text('Login'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class EventManager extends StatefulWidget {
  @override
  _EventManagerState createState() => _EventManagerState();
}

class _EventManagerState extends State<EventManager> {
  List<Event> events = [];
  List<String> imageUrls = [
    'https://midias.correiobraziliense.com.br/_midias/jpg/2024/03/04/675x450/1__heizzo_168-35286197.jpg?20240304155432?20240304155432',
    'https://encrypted-tbn1.gstatic.com/images?q=tbn:ANd9GcSHA2unR4zQcUo606GU3YCPUdMNPY5VQ8laQ5t0TZ04Lm5vmd0D',
    'https://st.depositphotos.com/53748278/52195/i/450/depositphotos_521957530-stock-photo-lasershow-festival-disco-party-background.jpg',
  ];
  int imageIndex = 0;

  void _addEvent() {
    TextEditingController eventController = TextEditingController();
    TextEditingController ticketPriceController = TextEditingController();
    DateTime selectedDate = DateTime.now();
    TimeOfDay selectedTime = TimeOfDay.now();

    showDialog(
      context: context,
      builder: (context) {
        return EventDialog(
          title: 'Adicionar Evento',
          eventController: eventController,
          ticketPriceController: ticketPriceController,
          selectedDate: selectedDate,
          selectedTime: selectedTime,
          onSave: () {
            setState(() {
              DateTime eventDateTime = DateTime(
                selectedDate.year,
                selectedDate.month,
                selectedDate.day,
                selectedTime.hour,
                selectedTime.minute,
              );
              double ticketPrice = double.tryParse(ticketPriceController.text) ?? 0.0;
              events.add(Event(
                name: eventController.text,
                date: eventDateTime,
                imageUrl: imageUrls[imageIndex],
                ticketPrice: ticketPrice,
              ));
              imageIndex = (imageIndex + 1) % imageUrls.length; // Update index
            });
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  void _editEvent(Event event) {
    TextEditingController eventController = TextEditingController(text: event.name);
    TextEditingController ticketPriceController = TextEditingController(text: event.ticketPrice.toString());
    DateTime selectedDate = event.date;
    TimeOfDay selectedTime = TimeOfDay.fromDateTime(event.date);

    showDialog(
      context: context,
      builder: (context) {
        return EventDialog(
          title: 'Editar Evento',
          eventController: eventController,
          ticketPriceController: ticketPriceController,
          selectedDate: selectedDate,
          selectedTime: selectedTime,
          onSave: () {
            setState(() {
              event.name = eventController.text;
              event.date = DateTime(
                selectedDate.year,
                selectedDate.month,
                selectedDate.day,
                selectedTime.hour,
                selectedTime.minute,
              );
              event.ticketPrice = double.tryParse(ticketPriceController.text) ?? 0.0;
            });
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  void _deleteEvent(Event event) {
    setState(() {
      events.remove(event);
    });
  }

  void _cancelEvent(Event event) {
    setState(() {
      event.isCancelled = true;
    });
  }

  void _addPerson(Event event) {
    showDialog(
      context: context,
      builder: (context) {
        TextEditingController personController = TextEditingController();
        TextEditingController emailController = TextEditingController();
        return AlertDialog(
          title: Text('Adicionar Pessoa ao ${event.name}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: personController,
                decoration: InputDecoration(
                  hintText: 'Nome da Pessoa',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
              ),
              SizedBox(height: 10),
              TextField(
                controller: emailController,
                decoration: InputDecoration(
                  hintText: 'Email da Pessoa',
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12.0),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            ElevatedButton(
              onPressed: () {
                setState(() {
                  event.addPerson(
                    personController.text,
                    emailController.text,
                    'https://via.placeholder.com/50',
                  );
                });
                Navigator.of(context).pop();
              },
              style: ElevatedButton.styleFrom(
                primary: Color.fromRGBO(2, 62, 131, 1),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12.0),
                ),
              ),
              child: Text('Adicionar'),
            ),
          ],
        );
      },
    );
  }

  void _removePerson(Event event, Person person) {
    setState(() {
      event.removePerson(person);
    });
  }

  void _shareEvent(Event event) {
    final String formattedDate = DateFormat('dd/MM/yyyy – kk:mm').format(event.date);
    final String eventDetails = 'Evento: ${event.name}\nData: $formattedDate\nPessoas adicionadas: ${event.persons.length}\nValor do Ingresso: ${event.ticketPrice.toStringAsFixed(2)}\nTotal Arrecadado: ${(event.ticketPrice * event.persons.length).toStringAsFixed(2)}';
    Share.share(eventDetails);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Gerenciador de Eventos'),
        backgroundColor: Color.fromRGBO(2, 62, 131, 1),
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: ListView.builder(
          itemCount: events.length,
          itemBuilder: (context, index) {
            return Card(
              color: events[index].isCancelled ? Colors.grey.withOpacity(0.75) : null,
              child: Column(
                children: <Widget>[
                  Image.network(
                    events[index].imageUrl,
                    height: 150,
                    width: double.infinity,
                    fit: BoxFit.cover,
                    color: events[index].isCancelled ? Colors.grey.withOpacity(0.75) : null,
                    colorBlendMode: events[index].isCancelled ? BlendMode.darken : null,
                  ),
                  ListTile(
                    title: Text(
                      events[index].name,
                      style: Theme.of(context).textTheme.headline6,
                    ),
                    subtitle: Text(
                      'Data: ${DateFormat('dd/MM/yyyy – kk:mm').format(events[index].date)}\nValor do Ingresso: ${events[index].ticketPrice.toStringAsFixed(2)}\nTotal Arrecadado: ${(events[index].ticketPrice * events[index].persons.length).toStringAsFixed(2)}',
                      style: Theme.of(context).textTheme.subtitle1,
                    ),
                    trailing: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: <Widget>[
                        IconButton(
                          icon: Icon(Icons.edit, color: Color.fromRGBO(2, 62, 131, 1)),
                          onPressed: () => _editEvent(events[index]),
                        ),
                        IconButton(
                          icon: Icon(Icons.person_add, color: Color.fromRGBO(2, 62, 131, 1)),
                          onPressed: () => _addPerson(events[index]),
                        ),
                        IconButton(
                          icon: Icon(Icons.share, color: Color.fromRGBO(2, 62, 131, 1)),
                          onPressed: () => _shareEvent(events[index]),
                        ),
                        IconButton(
                          icon: Icon(Icons.cancel, color: Colors.orange),
                          onPressed: () => _cancelEvent(events[index]),
                        ),
                        IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _deleteEvent(events[index]),
                        ),
                      ],
                    ),
                  ),
                  ExpansionTile(
                    title: Container(), // Empty container to prevent the tile from being empty
                    children: events[index].persons.map((person) {
                      return ListTile(
                        leading: CircleAvatar(
                          backgroundImage: NetworkImage(person.imageUrl),
                        ),
                        title: Text(person.name),
                        subtitle: Text(
                          'Email: ${person.email}\nAdicionado em: ${DateFormat('dd/MM/yyyy – kk:mm').format(person.dateAdded)}',
                        ),
                        trailing: IconButton(
                          icon: Icon(Icons.delete, color: Colors.red),
                          onPressed: () => _removePerson(events[index], person),
                        ),
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          },
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addEvent,
        child: Icon(Icons.add),
        backgroundColor: Color.fromRGBO(2, 62, 131, 1),
      ),
    );
  }
}

class Event {
  String name;
  DateTime date;
  String imageUrl;
  double ticketPrice;
  List<Person> persons;
  bool isCancelled;

  Event({
    required this.name,
    required this.date,
    required this.imageUrl,
    required this.ticketPrice,
    this.isCancelled = false,
  }) : persons = [];

  void addPerson(String personName, String email, String imageUrl) {
    persons.add(Person(name: personName, email: email, dateAdded: DateTime.now(), imageUrl: imageUrl));
  }

  void removePerson(Person person) {
    persons.remove(person);
  }
}

class Person {
  String name;
  String email;
  DateTime dateAdded;
  String imageUrl;

  Person({
    required this.name,
    required this.email,
    required this.dateAdded,
    required this.imageUrl,
  });

  @override
  String toString() {
    return '$name (email: $email, adicionado em ${dateAdded.toLocal()})';
  }
}

class EventDialog extends StatefulWidget {
  final String title;
  final TextEditingController eventController;
  final TextEditingController ticketPriceController;
  final DateTime selectedDate;
  final TimeOfDay selectedTime;
  final VoidCallback onSave;

  EventDialog({
    required this.title,
    required this.eventController,
    required this.ticketPriceController,
    required this.selectedDate,
    required this.selectedTime,
    required this.onSave,
  });

  @override
  _EventDialogState createState() => _EventDialogState();
}

class _EventDialogState extends State<EventDialog> {
  late DateTime selectedDate;
  late TimeOfDay selectedTime;

  @override
  void initState() {
    super.initState();
    selectedDate = widget.selectedDate;
    selectedTime = widget.selectedTime;
  }

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(widget.title),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          TextField(
            controller: widget.eventController,
            decoration: InputDecoration(
              hintText: 'Nome do Evento',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
          ),
          SizedBox(height: 10),
          TextField(
            controller: widget.ticketPriceController,
            decoration: InputDecoration(
              hintText: 'Valor do Ingresso',
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            keyboardType: TextInputType.numberWithOptions(decimal: true),
          ),
          SizedBox(height: 20),
          ElevatedButton(
            onPressed: () async {
              final DateTime? pickedDate = await showDatePicker(
                context: context,
                initialDate: selectedDate,
                firstDate: DateTime(2000),
                lastDate: DateTime(2101),
              );
              if (pickedDate != null && pickedDate != selectedDate) {
                setState(() {
                  selectedDate = pickedDate;
                });
              }
            },
            style: ElevatedButton.styleFrom(
              primary: Color.fromRGBO(2, 62, 131, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            child: Text('Selecionar Data'),
          ),
          ElevatedButton(
            onPressed: () async {
              final TimeOfDay? pickedTime = await showTimePicker(
                context: context,
                initialTime: selectedTime,
              );
              if (pickedTime != null && pickedTime != selectedTime) {
                setState(() {
                  selectedTime = pickedTime;
                });
              }
            },
            style: ElevatedButton.styleFrom(
              primary: Color.fromRGBO(2, 62, 131, 1),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
            ),
            child: Text('Selecionar Hora'),
          ),
        ],
      ),
      actions: [
        ElevatedButton(
          onPressed: widget.onSave,
          style: ElevatedButton.styleFrom(
            primary: Color.fromRGBO(2, 62, 131, 1),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12.0),
            ),
          ),
          child: Text('Salvar'),
        ),
      ],
    );
  }
}
